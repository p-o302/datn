<div class=""><img src="public/upload/{{ $product->productImage }}" style="vertical-align: middle;  width:80px;margin-right: 30px"></div>
<div class=""><p style="color: #4A235A;"><b>{{ $product->productName }}</b></p></div>
        