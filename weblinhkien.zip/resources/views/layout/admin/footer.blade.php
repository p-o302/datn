<footer class="main-footer">
    <strong>Edit by MrPhuc</strong>
    
    <div class="float-right d-none d-sm-inline-block">
     
    </div>
  </footer>