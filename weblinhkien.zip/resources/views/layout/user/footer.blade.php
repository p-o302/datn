  <!-- end body -->
  <!-- messinger -->
  <div class="hotro">
    <a href="https://www.messenger.com/t/phuclb2306" class="mess mb-4" >
      <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/6/6c/Facebook_Messenger_logo_2018.svg/1024px-Facebook_Messenger_logo_2018.svg.png" style="width: 60px;" alt="liên hệ" >
    </a>
  </div>
  <!-- end -->

      <!-- Phần cuối trang Footer-->
  <footer class="page-footer font-small mt-5">
  <div class="container-fluid text-center text-md-left ">
    <div class="row">
      <div class="col-md-4 mt-md-0 vien">
        <div class="d-flex p-3 text-white ml-5">
          <div class="p-2 "><i class="fab fa-facebook-messenger fa-3x"></i></div>

          <div class="p-2  mt-3"><h6>HỖ TRỢ TRỰC TUYẾN 24/7 </h6></div>
        </div>
      </div>
      <div class="col-md-4 mt-md-0 vien ">

        <div class="d-flex p-3 text-white">
          <div class="p-2 "><i class="fas fa-user-shield fa-3x"></i></div>

          <div class="p-2  mt-3"><h6>BẢO MẬT THÔNG TIN KHÁCH HÀNG </h6></div>
        </div>
        </div>

        <div class="col-md-4 mt-md-0 vien">

          <div class="d-flex p-3 text-white ml-5">
            <div class="p-2 "><i class="fas fa-shipping-fast fa-3x"></i></div>

            <div class="p-2  mt-3"><h6>GIAO HÀNG NHANH </h6></div>
          </div>
          </div>

      </div>
    </div>

      <!-- Grid column -->

      <hr class="clearfix w-100 d-md-none pb-3">

  <!-- Footer Elements -->
  <div class="container mt-3 mb-3">
    <h5 class="text-uppercase font-weight-bold">About Website</h5>
    <p class="mb-0">Contact to:</p>
    Email:  thaong302@gmail.com <br>
       Phone:  +84834474225

      <!-- Social buttons -->
          <ul class="list-unstyled text-center ">
            <li class="list-inline-item">
              <a href="https://www.facebook.com/Po.SauXanh/" class="btn btn-outline-warning mx-1">
                <i class="fab fa-facebook-f"> </i>
              </a>
            </li>
            <li class="list-inline-item">
              <a href="" class="btn btn-outline-warning mx-1">
                <i class="fab fa-twitter"> </i>
              </a>
            </li>
            <li class="list-inline-item">
              <a href="" class="btn btn-outline-warning mx-1">
                <i class="fab fa-google-plus-g"> </i>
              </a>
            </li>
          </ul>
          <!-- Social buttons -->

        </div>

        <!-- Copyright -->
        <div class="footer-copyright text-center py-2">© 2020 Copyright:
          <a href="http://sict.udn.vn/" style="color: white;"> SICT-BWD</a>
        </div>
        <!-- Copyright -->

      </footer>
