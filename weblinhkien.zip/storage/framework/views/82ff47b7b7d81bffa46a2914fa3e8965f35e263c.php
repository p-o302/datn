
<?php $__env->startSection('content'); ?>
<div class="container jumbotron   border border-success">
    <h2>Danh mục quản lý</h2>
           
    <table class="table">
      <thead class="bg-info text-white"> 
        <tr>
          <th>Các danh mục sản phẩm</th>
          
          <th>Thao tác</th>
        </tr>
      </thead>
      <tbody>
           <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <tr>
            <td><?php echo e($category->categoryName); ?></td>
            
            <td> <a class="button btn btn-danger " href="<?php echo e(route('product.show',$category->categoryID)); ?>"><i class="fas fa-info-circle"></i>  Chi tiết</a>
              <a class="button btn btn-success" href="<?php echo e(route('category.edit',$category->categoryID)); ?>"><i class="fas fa-tools"></i>  Sửa</a>
              <form class="d-inline-block " action="<?php echo e(route('category.destroy',$category->categoryID)); ?>" method="post" >
                <?php echo e(csrf_field()); ?>

                <?php echo method_field('DELETE'); ?>
                
                
                
                
                
                <input type="submit" value="Xóa" class="button btn btn-secondary">
                </form>
            
            </td>
          </tr>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        
 

      </tbody>
    </table>
    <div class="d-flex justify-content-center"><?php echo e($categories->links()); ?></div>
                <p class="d-flex justify-content-end">
                    <a class="btn btn-info btn-sm fa fa-plus" href="<?php echo e(route('category.create')); ?>">Thêm danh mục</a>
                </p>

  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\php\htdocs\dashboard\weblinhkien\resources\views/category/index.blade.php ENDPATH**/ ?>