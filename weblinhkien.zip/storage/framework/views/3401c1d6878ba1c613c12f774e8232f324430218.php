
<?php $__env->startSection('content'); ?>
<div style="margin-top: 100px;">
<div class="container jumbotron   border border-success">
    <h2>Tìm kiếm sản phẩm</h2>
           
    <table class="table">
      <thead> 
        <tr>
          <th>Tên danh mục</th>
            <th>Tên sản phẩm</th>
            <th>Ảnh sản phẩm</th>
         <th>Giá sản phẩm</th>
       
    
        </tr>
      </thead>
      <tbody>
       <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <tr>
        <td><?php echo e($row->categoryName); ?></td>
        <td><?php echo e($row->productName); ?></td>
      
        <td>
             <div class="product-image-thumb" ><img src="./public/upload/<?php echo e($row->productImage); ?>" style="width: 100px;" alt="Product Image"></div>
        </td>
        <td>
            <?php echo e(number_format($row->listPrice)); ?>đ 
        </td>
        
      </tr>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       


      </tbody>
    </table>
    
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.user.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\php\htdocs\dashboard\weblinhkien\resources\views/findhome.blade.php ENDPATH**/ ?>