
<?php $__env->startSection('content'); ?>

<div class="container jumbotron border border-success">
  <?php if(Session::has('message')): ?>
  <script type="text/javascript">
     swal({
         title:'Thành công!',
         text:"<?php echo e(Session::get('message')); ?>",
         timer:5000,
         type:'success'
     }).then((value) => {
       //location.reload();
     }).catch(swal.noop);
 </script>
 <?php endif; ?>
    <h2>Danh sách các đơn hàng</h2>
           
    <table class="table table-hover dataTable">
      <thead> 
        <tr role="row" class="bg-success text-white">
          <th>Tên người đặt</th>
            <th>Địa chỉ</th>
         <th>Ngày đặt hàng</th>
         <th>Email</th>
        <th>Trạng thái</th>
       <th>Thao tác</th>
       <th></th>
    
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($customer->name); ?></td>
          <td><?php echo e($customer->address); ?></td>
          <td><?php echo e($customer->created_at); ?></td>
          <td><?php echo e($customer->email); ?></td>
             <td>
               <?php echo e($customer->status); ?>

             </td>
          
          <td> 
            <a class="button btn btn-success" href="<?php echo e(route('bill.edit',$customer->id)); ?>"><i class="fas fa-info-circle"></i> Chi tiết</a>
            <form class="d-inline-block " action="<?php echo e(route('bill.destroy',$customer->id)); ?>" method="post" >
              <?php echo e(csrf_field()); ?>

              <?php echo method_field('DELETE'); ?>
              
              
              
              
             
             <button type="submit" class="button btn btn-danger"> <i class="fas fa-trash-alt"></i> Xóa</button>
              </form>
          
          </td>
        </tr>
       

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
   

  </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\php\htdocs\dashboard\weblinhkien\resources\views/order/index.blade.php ENDPATH**/ ?>